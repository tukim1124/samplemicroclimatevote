#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.health-1.0.mf=2b7b643efe4833e6445c687f470c55f2
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.health.1.0_1.0.21.jar=96d9d6d5269a75c7506d63a0d5d98ecd
