#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.cdi1.2-transaction1.2.mf=e7b93fa39a07e16857a4612b106d9168
lib/com.ibm.ws.cdi.transaction_1.0.21.jar=c2b4f3e0e8f45d2950f9ca620b64a9a1
