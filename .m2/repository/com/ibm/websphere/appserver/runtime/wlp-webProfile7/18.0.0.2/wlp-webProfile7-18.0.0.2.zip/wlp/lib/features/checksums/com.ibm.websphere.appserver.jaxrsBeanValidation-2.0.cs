#Tue Jun 19 06:25:11 BST 2018
lib/com.ibm.ws.jaxrs.2.0.beanvalidation_1.0.21.jar=1653f3d0c11f5bf9985b282ea7667c8e
lib/features/com.ibm.websphere.appserver.jaxrsBeanValidation-2.0.mf=496658ec9259a3f74933039423d10a1f
