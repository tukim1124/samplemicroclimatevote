#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.javax.annotation-1.1.mf=caa61595e92b59e1887611b77ffe365c
dev/api/spec/com.ibm.websphere.javaee.annotation.1.1_1.0.21.jar=c186d9febd8c046ce244134b8b907f97
