#Tue Jun 19 06:25:10 BST 2018
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.webCache_1.1-javadoc.zip=a44fb8c19ac9081ec94e5add31e459f7
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.webCache_1.0-javadoc.zip=233c11bef798bb1eb1f83e4f721dffb9
dev/api/ibm/schema/cachespec.xsd=4c363b074382cb0c1762f596c91bdfa4
lib/features/com.ibm.websphere.appserver.webCache-1.0.mf=0487017c6b181690ff93fb8b4cf96b6b
lib/com.ibm.ws.dynacache.web_1.0.21.jar=02dbf5eff25bfb44ef0abaf520daaad5
dev/api/ibm/com.ibm.websphere.appserver.api.webCache_1.1.21.jar=61f49ce4a9f4341006784696c0313cee
dev/spi/ibm/com.ibm.websphere.appserver.spi.webCache_1.0.21.jar=c7b52d183a3adeb177d4c085292c5de0
