#Tue Jun 19 06:25:12 BST 2018
dev/api/spec/com.ibm.websphere.javaee.cdi.1.2_1.2.21.jar=9423edfd32ac4172ae52bd8780c3dddb
lib/features/com.ibm.websphere.appserver.javax.cdi-1.2.mf=5dc0a96adb460d34f6b44f5dce46a6ae
