#Tue Jun 19 06:25:12 BST 2018
lib/features/com.ibm.websphere.appserver.microProfile-1.0.mf=f5d1664379ddb3923fb391336fb11ff8
lib/com.ibm.ws.require.java8_1.0.21.jar=5de0ed4feb1dee14ece005df35bf77da
