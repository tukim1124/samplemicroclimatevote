#Tue Jun 19 06:25:12 BST 2018
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.21.jar=7e500cd9d7e3eac046cc7a00c771b6fc
lib/features/com.ibm.websphere.appserver.javax.jsp-2.3.mf=31691a6f0cef903d0bcbc76b2a9ece31
