#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.mpConfig1.1-cdi1.2.mf=d63fa8262bf3854b540ba66036354809
lib/com.ibm.ws.microprofile.config.cdi_1.0.21.jar=2ae6adf20bc7a5348cbca4e0fb3a3f66
