#Tue Jun 19 06:25:10 BST 2018
lib/features/com.ibm.websphere.appserver.mpRestClient1.0-cdi1.2.mf=1b7b0f6ca69935eee726120004a77b41
lib/com.ibm.ws.microprofile.rest.client.cdi_1.0.21.jar=6a24c2015b7ac691e234f4a2b0d4cf9e
