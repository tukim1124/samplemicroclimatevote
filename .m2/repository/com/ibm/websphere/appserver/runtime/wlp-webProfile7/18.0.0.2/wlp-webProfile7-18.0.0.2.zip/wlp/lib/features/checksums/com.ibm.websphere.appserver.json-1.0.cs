#Tue Jun 19 06:25:10 BST 2018
lib/com.ibm.json4j_1.0.21.jar=268175c75ab77a443a5fa733f2e554a2
lib/features/com.ibm.websphere.appserver.json-1.0.mf=898413ec162e956ba259a4edd3f1c0bc
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.json_1.0-javadoc.zip=5fdc52080e2f8edb91746c755eb2523c
dev/api/ibm/com.ibm.websphere.appserver.api.json_1.0.21.jar=8ae482e459a1f02b99226f93e0f04f33
