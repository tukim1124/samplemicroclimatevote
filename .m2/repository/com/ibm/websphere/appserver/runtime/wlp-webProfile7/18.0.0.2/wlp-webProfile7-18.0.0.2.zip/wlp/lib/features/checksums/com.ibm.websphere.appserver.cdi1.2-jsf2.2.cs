#Tue Jun 19 06:25:11 BST 2018
lib/com.ibm.ws.cdi.1.2.jsf_1.0.21.jar=227faf1a50f8d982277ddeb498a30365
lib/features/com.ibm.websphere.appserver.cdi1.2-jsf2.2.mf=fa9102090b99c06778dd5636ec660857
