#Tue Jun 19 06:25:11 BST 2018
lib/com.ibm.ws.jaxrs.2.0.security_1.0.21.jar=c9c2fff8505f4a4be9a00a0125e2a5ba
lib/features/com.ibm.websphere.appserver.jaxrsAppSecurity-2.0.mf=ee685942c45e4ffd4fad6098b157a530
