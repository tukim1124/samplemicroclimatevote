#Tue Jun 19 06:25:11 BST 2018
lib/com.ibm.ws.jpa.container.beanvalidation.1.1_1.0.21.jar=a54406484404b7705398c1f8798486da
lib/features/com.ibm.websphere.appserver.jpa2.0-2.1-bv1.1.mf=fb3e5164ca31a459d65a83764fbf0fc6
