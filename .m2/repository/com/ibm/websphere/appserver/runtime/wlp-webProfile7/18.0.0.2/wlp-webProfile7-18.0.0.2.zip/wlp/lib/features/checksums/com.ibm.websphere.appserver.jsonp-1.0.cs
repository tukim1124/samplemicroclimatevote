#Tue Jun 19 06:25:12 BST 2018
dev/api/spec/com.ibm.websphere.javaee.jsonp.1.0_1.0.21.jar=35981ccaa7e22d0b0c2f843c7c76ef34
lib/features/com.ibm.websphere.appserver.jsonp-1.0.mf=1758058ccf70773da6e5eaf7db964b5a
lib/com.ibm.ws.org.glassfish.json.1.0_1.0.21.jar=d47549a45028d0c010f3733196966966
