#Tue Jun 19 06:25:10 BST 2018
lib/com.ibm.ws.microprofile.config.1.2.cdi_1.0.21.jar=50dcc3583d9107d91f2ff275c6e1839d
lib/features/com.ibm.websphere.appserver.mpConfig1.2-cdi1.2.mf=45714879e57bd6fdc2c57462a2ea7c1e
