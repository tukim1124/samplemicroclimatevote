#Tue Jun 19 06:25:10 BST 2018
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.openapi.1.0_1.0.21.jar=4a6f49e57c01c5cae2d7fbf43185a7d2
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.openapi-1.0.mf=12ff49ab92a9c08aa1ed454da50861fb
