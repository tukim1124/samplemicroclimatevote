#Tue Jun 19 06:25:12 BST 2018
lib/com.ibm.ws.jca.cm_1.0.21.jar=b6b151e0557a465b65822ec6aa120521
lib/features/com.ibm.websphere.appserver.connectionManagement-1.0.mf=444c4a463eda0341f61860ec2edfe0cd
