#Tue Jun 19 06:25:10 BST 2018
lib/com.ibm.ws.org.apache.commons.lang3.3.5_1.0.21.jar=d5e7080ab57edc896885d8209d05372c
lib/com.ibm.ws.microprofile.config.1.2_1.0.21.jar=1754163ea3f8081ef7064c16ea6d4c5a
lib/features/com.ibm.websphere.appserver.mpConfig-1.2.mf=e55d467678c6eb911a6b5a3c019f54c8
lib/com.ibm.ws.require.java8_1.0.21.jar=5de0ed4feb1dee14ece005df35bf77da
