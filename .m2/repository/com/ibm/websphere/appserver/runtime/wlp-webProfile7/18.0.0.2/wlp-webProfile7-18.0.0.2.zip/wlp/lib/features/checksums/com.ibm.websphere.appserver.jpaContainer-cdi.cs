#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.jpaContainer-cdi.mf=8ec023b9861f1842b6503b978658202a
lib/com.ibm.ws.jpa.container.v21.cdi_1.0.21.jar=bbd21f63dde9c70ab3c5ffc8bf937116
