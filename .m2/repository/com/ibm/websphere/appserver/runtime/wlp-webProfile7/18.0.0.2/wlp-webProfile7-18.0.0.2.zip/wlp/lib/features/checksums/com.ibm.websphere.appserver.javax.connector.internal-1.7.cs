#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.7.mf=e4610a3c45d3b36cfd8c3e74e544200d
dev/api/spec/com.ibm.websphere.javaee.connector.1.7_1.0.21.jar=bfd17d1cc9490adb2739c65332564af3
