#Tue Jun 19 06:25:11 BST 2018
dev/api/spec/com.ibm.websphere.javaee.connector.1.6_1.0.21.jar=fd2cef24b9e72aa37890dd70b2f5cfc7
lib/features/com.ibm.websphere.appserver.javax.connector.internal-1.6.mf=397b71c4d2886e4f342699e07ff1b4e9
