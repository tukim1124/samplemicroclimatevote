#Tue Jun 19 06:25:11 BST 2018
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.rest.client.1.0_1.0.21.jar=02eaadc124bdf8d7f152861ea5264597
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.rest.client-1.0.mf=0b30f540aa080a7125d8c61271475fc5
