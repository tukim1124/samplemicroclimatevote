#Tue Jun 19 06:25:10 BST 2018
lib/features/com.ibm.websphere.appserver.mpOpenAPI-1.0.mf=27eab647dc2f953e50cea911a7c2dee4
lib/com.ibm.ws.microprofile.openapi.ui_1.0.21.jar=70343f3724d75c8c7150cdfea36eaa86
lib/com.ibm.ws.microprofile.openapi_1.0.21.jar=844d956d05ea0b12c133ed9076651814
lib/com.ibm.ws.com.fasterxml.jackson.2.9.1_1.0.21.jar=562683115c4822ea3b07ef4befd25da0
lib/com.ibm.ws.require.java8_1.0.21.jar=5de0ed4feb1dee14ece005df35bf77da
