#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.jta-1.2.mf=1ab3a564273758f87e16d1ab63a08dd0
dev/api/spec/com.ibm.websphere.javaee.transaction.1.2_1.0.21.jar=eb1c221e25211552cb2fd31cfe24f47a
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.21.jar=b2dab4642ca6c570ede9c8fb6d946942
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=4d4c31866a6691758cbca408ff1e433d
