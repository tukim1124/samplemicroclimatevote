#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.mpJwt-1.0.mf=d1af72d5b9c7b398e267a9ce6f22cf9d
lib/com.ibm.ws.org.apache.commons.logging.1.0.3_1.0.21.jar=05fe77456faf6d9cafb8dd6df644cc4f
lib/com.ibm.ws.org.apache.commons.codec.1.4_1.0.21.jar=4b7263ad4629fb1a4c9ab390dbb877d4
lib/com.ibm.ws.security.mp.jwt.cdi_1.0.21.jar=0184c18c39c37b8b6b70793eb38d8907
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.jwt.1.0_1.0.21.jar=062491ce63a0cb9aa0ec35b8c5f6c1ce
lib/com.ibm.ws.security.mp.jwt_1.0.21.jar=0c9135cdc10573a3db3837ac8007e77d
