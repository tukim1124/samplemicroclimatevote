#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.jpaContainer-2.1.mf=a5f3405f45b1894175741f96d203d911
lib/com.ibm.ws.jpa.container.thirdparty_1.0.21.jar=45f39f6e19edc6000848fe3c8fef09df
lib/com.ibm.ws.jpa.container_1.0.21.jar=9cb19c69ace761f822d1c66b5b7bec53
lib/com.ibm.ws.jpa.container.v21_1.0.21.jar=d8283ff279858d4ac85b2719cb748062
