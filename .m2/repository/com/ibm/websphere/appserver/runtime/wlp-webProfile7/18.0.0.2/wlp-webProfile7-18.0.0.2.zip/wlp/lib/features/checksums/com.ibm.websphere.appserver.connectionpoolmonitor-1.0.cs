#Tue Jun 19 06:25:12 BST 2018
lib/features/com.ibm.websphere.appserver.connectionpoolmonitor-1.0.mf=12bfd3b61174869b091d6322da9c7783
dev/api/ibm/com.ibm.websphere.appserver.api.connectionpool_1.0.21.jar=de384a7a800b6450066b99748da0a753
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.connectionpool_1.0-javadoc.zip=6335cd351ca50e17494022db5de620b4
lib/com.ibm.ws.connectionpool.monitor_1.0.21.jar=aa3a1ce68ffb486bc8db06fdab4bec3d
