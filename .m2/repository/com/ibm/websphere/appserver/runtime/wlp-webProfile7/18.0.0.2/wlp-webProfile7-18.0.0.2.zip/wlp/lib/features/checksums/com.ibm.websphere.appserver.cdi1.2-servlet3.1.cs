#Tue Jun 19 06:25:11 BST 2018
dev/api/spec/com.ibm.websphere.javaee.jsp.2.3_1.0.21.jar=7e500cd9d7e3eac046cc7a00c771b6fc
lib/features/com.ibm.websphere.appserver.cdi1.2-servlet3.1.mf=4344e360d9d84e79b4205f6487dfa8cd
lib/com.ibm.ws.cdi.1.2.web_1.0.21.jar=80cc7a6e5b321335a8872a3185a52799
lib/com.ibm.ws.cdi.web_1.0.21.jar=8054a989cbef51dcbab8c09e1ef995a1
