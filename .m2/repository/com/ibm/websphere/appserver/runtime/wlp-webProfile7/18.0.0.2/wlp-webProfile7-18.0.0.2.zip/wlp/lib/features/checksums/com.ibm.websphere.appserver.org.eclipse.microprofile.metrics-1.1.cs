#Tue Jun 19 06:25:11 BST 2018
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.metrics.1.1.1_1.0.21.jar=429ac6e72e8800a500a660810491fb4e
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.metrics-1.1.mf=f93168cf151f24ecc1a6694a55881628
