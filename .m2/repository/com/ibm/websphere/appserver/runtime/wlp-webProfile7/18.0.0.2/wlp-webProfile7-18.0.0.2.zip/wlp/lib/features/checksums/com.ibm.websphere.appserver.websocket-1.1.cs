#Tue Jun 19 06:25:11 BST 2018
dev/api/ibm/com.ibm.websphere.appserver.api.wsoc_1.0.21.jar=3d33f2ec0ac346546520912caf549809
lib/com.ibm.ws.wsoc.1.1_1.0.21.jar=7598724d025fecf3e6abc3c0f6dcdc62
lib/com.ibm.ws.wsoc_1.0.21.jar=3f58b41734e8d25fbac3eb4787088061
lib/features/com.ibm.websphere.appserver.websocket-1.1.mf=368ee86373b76bac2e1566dc5e74d57e
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.wsoc_1.0-javadoc.zip=bb03282e74e2a8328e69b5ba47a89840
dev/api/spec/com.ibm.websphere.javaee.websocket.1.1_1.0.21.jar=3c3eb77bf02e038d09ec2e2df2671c70
