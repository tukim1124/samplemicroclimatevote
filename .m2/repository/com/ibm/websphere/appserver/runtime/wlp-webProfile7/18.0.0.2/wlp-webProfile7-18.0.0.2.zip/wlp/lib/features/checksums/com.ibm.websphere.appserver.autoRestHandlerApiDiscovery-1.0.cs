#Tue Jun 19 06:25:10 BST 2018
lib/com.ibm.websphere.rest.api.discovery_1.0.21.jar=6b380b7091131f89e2886ac343de9cd7
lib/features/com.ibm.websphere.appserver.autoRestHandlerApiDiscovery-1.0.mf=30d20934a4d2647cd90dcd4867c5eaf5
dev/spi/ibm/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0.21.jar=31571b2b1d16765c2759e5b950cf836e
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restAPIDiscovery_2.0-javadoc.zip=979d372fb455c6a7508907992954c236
