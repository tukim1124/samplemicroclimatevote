#Tue Jun 19 06:25:12 BST 2018
lib/features/com.ibm.websphere.appserver.jaxrsClient-2.0.mf=88ea38dc051d88a48b46b0035b9b7497
lib/com.ibm.ws.jaxrs.2.0.client_1.0.21.jar=df706071a2e1753cc434f1ba9096d468
