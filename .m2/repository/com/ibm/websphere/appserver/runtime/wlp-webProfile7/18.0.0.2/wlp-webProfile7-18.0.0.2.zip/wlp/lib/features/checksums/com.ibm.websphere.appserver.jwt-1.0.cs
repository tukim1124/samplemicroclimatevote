#Tue Jun 19 06:25:11 BST 2018
lib/com.ibm.ws.com.google.gson.2.2.4_1.0.21.jar=a3f1fe3e397c4c2ace478188386fc2fa
lib/features/com.ibm.websphere.appserver.jwt-1.0.mf=454b144541addbdfa07f5be53ccf8f35
lib/com.ibm.ws.org.slf4j.api.1.7.7_1.0.21.jar=2afcd9887ae80b3bad89124ffc95116d
lib/com.ibm.ws.org.apache.commons.codec.1.4_1.0.21.jar=4b7263ad4629fb1a4c9ab390dbb877d4
lib/com.ibm.json4j_1.0.21.jar=268175c75ab77a443a5fa733f2e554a2
lib/com.ibm.ws.security.jwt_1.0.21.jar=b0595a045977169c5c496c7ac0271872
lib/com.ibm.ws.org.slf4j.jdk14.1.7.7_1.0.21.jar=353669ff714ec2ee6bfedd63cd2ae2d1
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jwt_1.1-javadoc.zip=797bd683f390944a176cc2b2607c7bf9
dev/api/ibm/com.ibm.websphere.appserver.api.jwt_1.1.21.jar=b95dc07692ef4d92ae7010da7b4169bd
lib/com.ibm.ws.security.common_1.0.21.jar=da191b597bc80d01824c1edb9945e2fc
lib/com.ibm.ws.org.jose4j.0.5.1_1.0.21.jar=dbdcb2fc6838b61cf27ad26abdd4857e
