#Tue Jun 19 06:25:12 BST 2018
lib/features/com.ibm.websphere.appserver.dynamicBundle-1.0.mf=e9f6f77033e1c60fb697f9f7b2e1cade
lib/com.ibm.ws.dynamic.bundle_1.0.21.jar=bd24044c8110b57716108ca264e36e22
