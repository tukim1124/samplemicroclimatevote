#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.cdi1.2-jndi1.0.mf=481eae8ee8c6abc24a2982612f8292be
lib/com.ibm.ws.cdi.jndi_1.0.21.jar=d56633190b3fcf0d32041ac35f57a1b0
