#Tue Jun 19 06:25:11 BST 2018
lib/com.ibm.ws.beanvalidation.v11.cdi_1.0.21.jar=d9d0214a27699d49ae44a3ebe83af227
lib/features/com.ibm.websphere.appserver.beanValidationCDI-1.0.mf=9fe1c3d07a60ed9406478dd1cfe158db
