#Tue Jun 19 06:25:10 BST 2018
lib/features/com.ibm.websphere.appserver.mpFaultTolerance1.0-cdi1.2.mf=bc9f19042195e32f19e677ddf55e623b
lib/com.ibm.ws.microprofile.faulttolerance.cdi_1.0.21.jar=e8bef0068ad1cebe203754b12f0e7b25
