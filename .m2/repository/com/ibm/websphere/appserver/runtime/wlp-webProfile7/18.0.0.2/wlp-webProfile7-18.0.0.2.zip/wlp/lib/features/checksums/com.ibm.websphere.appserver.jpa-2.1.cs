#Tue Jun 19 06:25:11 BST 2018
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink_1.0.21.jar=f2d2d0b97b12788a7af2f5b0771cd255
lib/com.ibm.ws.jpa.container.eclipselink_1.0.21.jar=3f85fd81d476162780855207999b6fe7
lib/features/com.ibm.websphere.appserver.jpa-2.1.mf=cc5016aefc278a3e6ec0856c704ff181
