#Tue Jun 19 06:25:11 BST 2018
lib/com.ibm.ws.require.java8_1.0.21.jar=5de0ed4feb1dee14ece005df35bf77da
lib/features/com.ibm.websphere.appserver.mpOpenTracing-1.0.mf=6495896aed265b64b7207d8102343f18
lib/com.ibm.ws.microprofile.opentracing_1.0.21.jar=3e2883ea465ea7d760ffe1d000c6ea4c
