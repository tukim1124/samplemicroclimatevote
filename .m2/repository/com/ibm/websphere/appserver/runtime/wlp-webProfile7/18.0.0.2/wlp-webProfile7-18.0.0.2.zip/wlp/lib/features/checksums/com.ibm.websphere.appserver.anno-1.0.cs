#Tue Jun 19 06:25:10 BST 2018
lib/features/com.ibm.websphere.appserver.anno-1.0.mf=4e46a6b64f0c1e224086b739c124a852
lib/com.ibm.ws.anno_1.0.21.jar=c11e9eee5a3631f06252fa514705e2dc
dev/spi/ibm/com.ibm.websphere.appserver.spi.anno_1.1.21.jar=cc4d8e8c6c2819833e920d035a32d3ab
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.anno_1.1-javadoc.zip=e1287a5c4153b6fc07eec8fad26fba98
