#Tue Jun 19 06:25:12 BST 2018
dev/api/spec/com.ibm.websphere.javaee.persistence.2.1_1.0.21.jar=fc66c1f5b43b499eac7196652de02267
lib/features/com.ibm.websphere.appserver.javax.persistence-2.1.mf=c1a65a814dc794dafff5d1f65c21306d
lib/com.ibm.ws.javaee.persistence.api.2.1_1.0.21.jar=743978d17a071ff9d7333873eaeb5dec
