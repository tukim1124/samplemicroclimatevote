#Tue Jun 19 06:25:12 BST 2018
lib/com.ibm.ws.jndi.url.contexts_1.0.21.jar=d5b5a8a57e71e628bf5c61dc49bee96f
lib/com.ibm.ws.jndi_1.0.21.jar=185cc4b6a14bfc8571a5742f0934e610
lib/features/com.ibm.websphere.appserver.jndi-1.0.mf=aab9ca4f856d193df3040e66ad062cb8
lib/com.ibm.ws.org.apache.aries.jndi.core_1.1.21.jar=8162cb0fc7274f4f91f65535ead98ea9
lib/com.ibm.ws.org.apache.aries.jndi.api_1.1.21.jar=8f1fe9191f9c1a823e92aaf166953ab9
