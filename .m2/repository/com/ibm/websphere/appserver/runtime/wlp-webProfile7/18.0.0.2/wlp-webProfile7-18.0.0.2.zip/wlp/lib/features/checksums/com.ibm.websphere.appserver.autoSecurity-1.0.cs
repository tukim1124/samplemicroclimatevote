#Tue Jun 19 06:25:11 BST 2018
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.security.spnego_1.0-javadoc.zip=dba2714110fb99e61a7cfeddb5173841
lib/features/com.ibm.websphere.appserver.autoSecurity-1.0.mf=1d9d5227bc7fe40484217650c9962aa8
dev/api/ibm/com.ibm.websphere.appserver.api.security.spnego_1.0.21.jar=84b1e425b4d88d342d8cf397227b957d
