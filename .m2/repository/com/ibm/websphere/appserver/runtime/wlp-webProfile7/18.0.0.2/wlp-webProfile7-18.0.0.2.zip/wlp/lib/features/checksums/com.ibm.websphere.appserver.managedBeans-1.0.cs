#Tue Jun 19 06:25:11 BST 2018
dev/api/ibm/schema/ibm-managed-bean-bnd_1_0.xsd=914d243e72b5fdf8dfbff4f6be3e4bc9
dev/api/ibm/schema/ibm-managed-bean-bnd_1_1.xsd=d90f6abac37958438d8018aa10797eee
lib/com.ibm.ws.managedbeans_1.0.21.jar=2f8c7ffc52e6c79dbd4128c895319ddb
lib/features/com.ibm.websphere.appserver.managedBeans-1.0.mf=bcaf7ff52700746f55f1e7b978da3567
