#Tue Jun 19 06:25:10 BST 2018
lib/features/com.ibm.websphere.appserver.javax.interceptor-1.1.mf=390512ca81b33a459735f5c68b4e674a
dev/api/spec/com.ibm.websphere.javaee.interceptor.1.1_1.0.21.jar=424736a1345b73a402d0e4fb1b2460f5
