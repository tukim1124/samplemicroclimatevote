#Tue Jun 19 06:25:10 BST 2018
lib/com.ibm.ws.cdi.1.2.ejb_1.0.21.jar=f8fda12244c8e8fa1f65befefefd3b50
lib/com.ibm.ws.cdi.ejb.common_1.0.21.jar=6acf8b14bea7fe9b5569417941d96884
lib/features/com.ibm.websphere.appserver.cdi1.2-ejb3.2.mf=4d507bef070e1375a4b932d5efe4ce91
