#Tue Jun 19 06:25:12 BST 2018
lib/com.ibm.ws.jaxrs.2.0.managedbeans_1.0.21.jar=373b7f8314d60fc9f063382f8f0b1b9d
lib/features/com.ibm.websphere.appserver.jaxrs20managedbeans-1.0.mf=af0b0c2ffa2c64c2e6c5d635548abd94
