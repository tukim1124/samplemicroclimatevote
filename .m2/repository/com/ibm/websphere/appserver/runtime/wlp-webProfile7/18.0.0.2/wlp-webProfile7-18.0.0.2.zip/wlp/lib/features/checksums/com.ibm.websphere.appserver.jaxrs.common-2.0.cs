#Tue Jun 19 06:25:10 BST 2018
dev/api/spec/com.ibm.websphere.javaee.jaxrs.2.0_1.0.21.jar=e134128a4f3947d19b514c111e1c2f22
lib/com.ibm.ws.org.apache.ws.xmlschema.core.2.0.3_1.0.21.jar=ff9361705efbb77366407fa97a44a9f8
lib/com.ibm.ws.org.apache.xml.resolver.1.2_1.0.21.jar=15b56d837bc6636c1f40e53ddcd65848
dev/api/ibm/com.ibm.websphere.appserver.api.jaxrs20_1.0.21.jar=4a038857768fdbfab055b0afc0c81d98
lib/com.ibm.ws.org.apache.neethi.3.0.2_1.0.21.jar=51a4fddb1b10dc52b8266849d031c3f0
lib/com.ibm.ws.jaxrs.2.x.config_1.0.21.jar=6aedad7036e47284a348daf6a7a33c41
lib/com.ibm.ws.jaxrs.2.0.common_1.0.21.jar=34b352d9a7229126ceccd2164daf84a8
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.jaxrs20_1.0-javadoc.zip=ced3f04570e6a97681d2443de2148760
lib/com.ibm.ws.jaxrs.2.0.tools_1.0.21.jar=cc6a68370001633f0ce0af0c7f3b1e24
bin/jaxrs/tools/wadl2java.jar=eaf0c80fbec5d5c242d46156e811c793
lib/features/com.ibm.websphere.appserver.jaxrs.common-2.0.mf=f58ca320d31b63430f4e8b989b0b86f7
