#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.javax.persistence.base-2.1.mf=c9ddee9f64b7f508ddc277bde6cb973e
lib/com.ibm.ws.javaee.persistence.2.1_1.0.21.jar=b979450e43045f7e4443ecb881a3044e
