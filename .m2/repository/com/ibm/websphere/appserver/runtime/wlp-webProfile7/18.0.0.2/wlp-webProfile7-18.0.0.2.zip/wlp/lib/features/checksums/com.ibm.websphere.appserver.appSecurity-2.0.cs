#Tue Jun 19 06:25:12 BST 2018
lib/features/com.ibm.websphere.appserver.appSecurity-2.0.mf=f96433ddec9ffdd99dcb3d1f38aae36e
lib/com.ibm.ws.security.authentication.tai_1.0.21.jar=3c20ae1394169ce83a6d4c4d428f5d56
