#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.mpMetrics1.1-cdi1.2.mf=e6d872c5a0022e0b8600d549d73de3fe
lib/com.ibm.ws.microprofile.metrics.1.1.cdi_1.0.21.jar=56898ce3ec069322a2d4c2249e5082c0
