#Tue Jun 19 06:25:10 BST 2018
lib/com.ibm.ws.wsoc.cdi.weld_1.0.21.jar=fba9fc5918de821c9a2f14345785b1c4
lib/features/com.ibm.websphere.appserver.websocketCDI-1.2.mf=0bcbb563dfcbe23be42bf44ce45f4cd9
