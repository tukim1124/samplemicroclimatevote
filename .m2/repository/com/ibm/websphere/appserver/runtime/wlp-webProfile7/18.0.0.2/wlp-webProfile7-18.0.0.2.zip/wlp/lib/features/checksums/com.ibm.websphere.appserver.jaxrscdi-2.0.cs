#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.jaxrscdi-2.0.mf=9d87a9f31c4275b38f66578e658e0c3c
lib/com.ibm.ws.jaxrs.2.0.cdi_1.0.21.jar=ce7fe1853271caca29ab640da81afeaf
