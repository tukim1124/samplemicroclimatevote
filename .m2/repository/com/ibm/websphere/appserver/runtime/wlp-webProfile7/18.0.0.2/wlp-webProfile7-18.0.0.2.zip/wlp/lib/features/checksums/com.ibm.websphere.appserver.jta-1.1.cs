#Tue Jun 19 06:25:10 BST 2018
dev/api/spec/com.ibm.websphere.javaee.transaction.1.1_1.0.21.jar=f075f0cd30e17faf1ff0fdcd13e5ce1b
lib/features/com.ibm.websphere.appserver.jta-1.1.mf=dcfabfa9285a51bc10fc9fdf70b517ce
dev/api/ibm/com.ibm.websphere.appserver.api.transaction_1.1.21.jar=b2dab4642ca6c570ede9c8fb6d946942
dev/api/ibm/javadoc/com.ibm.websphere.appserver.api.transaction_1.1-javadoc.zip=4d4c31866a6691758cbca408ff1e433d
