#Tue Jun 19 06:25:12 BST 2018
lib/features/com.ibm.websphere.appserver.injection-1.0.mf=d9045f8cb356cd98e17a9da7ebe365fb
lib/com.ibm.ws.injection_1.0.21.jar=fa0150509f58159c9bb124816119ee0c
