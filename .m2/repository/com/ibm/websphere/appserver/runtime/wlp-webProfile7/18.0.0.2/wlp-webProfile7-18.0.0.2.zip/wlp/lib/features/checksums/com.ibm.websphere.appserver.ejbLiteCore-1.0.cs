#Tue Jun 19 06:25:10 BST 2018
lib/features/com.ibm.websphere.appserver.ejbLiteCore-1.0.mf=123da796f83d3e01487ac72f54c61352
lib/com.ibm.ws.ejbcontainer.session_1.0.21.jar=eee2b6f5a39b08c23397e78d6115ad94
