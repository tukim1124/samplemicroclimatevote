#Tue Jun 19 06:25:10 BST 2018
lib/features/com.ibm.websphere.appserver.restHandler-1.0.mf=12f8ebb0bcc0fddad4bc7fec3c388c07
lib/com.ibm.ws.rest.handler_1.0.21.jar=edb17a34152617df3fc858e62772276f
dev/spi/ibm/com.ibm.websphere.appserver.spi.restHandler_2.0.21.jar=96d62e871475ced17e1e691012a7419a
lib/com.ibm.websphere.jsonsupport_1.0.21.jar=9c1baf456be71ffcc84e09506cf2a1a3
lib/com.ibm.websphere.rest.handler_1.0.21.jar=e89abd0001f4e84743242db2d2ea709f
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.restHandler_2.0-javadoc.zip=468fc6e89c439d95b6754386643b896f
lib/com.ibm.ws.org.joda.time.1.6.2_1.0.21.jar=446a3a8aa53a43bebcce002676ec05fd
