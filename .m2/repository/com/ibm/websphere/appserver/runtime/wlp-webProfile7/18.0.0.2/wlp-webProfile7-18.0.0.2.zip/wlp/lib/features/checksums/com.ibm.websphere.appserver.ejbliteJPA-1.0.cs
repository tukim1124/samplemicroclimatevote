#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.ejbliteJPA-1.0.mf=764e9dfcc0b8c8cf68b80ebaeca6fa3b
lib/com.ibm.ws.ejbcontainer.jpa_1.0.21.jar=ea68fc29270b0873d3322f81212d2a2e
