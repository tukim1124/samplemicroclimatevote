#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.javax.ejb-3.1.mf=9305e4d0d6c01f16b63997d9ebbeb8cf
dev/api/spec/com.ibm.websphere.javaee.ejb.3.1_1.0.21.jar=1ed81af208db84e8cf62a2a8ac6e25dc
