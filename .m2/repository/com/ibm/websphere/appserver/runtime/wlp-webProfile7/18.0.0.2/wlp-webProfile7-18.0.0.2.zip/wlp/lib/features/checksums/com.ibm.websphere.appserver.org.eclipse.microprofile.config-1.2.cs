#Tue Jun 19 06:25:10 BST 2018
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.config.1.2.1_1.0.21.jar=31e4f589b6ef0dec9818668a65656bca
lib/features/com.ibm.websphere.appserver.org.eclipse.microprofile.config-1.2.mf=f06eb7c5c191fe15e08fd108633003bf
