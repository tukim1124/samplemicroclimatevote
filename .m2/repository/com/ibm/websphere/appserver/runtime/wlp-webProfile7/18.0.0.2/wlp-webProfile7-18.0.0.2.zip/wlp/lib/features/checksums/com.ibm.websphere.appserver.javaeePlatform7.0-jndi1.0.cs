#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.javaeePlatform7.0-jndi1.0.mf=a3a428bf973427b69fe50604f329b0ac
lib/com.ibm.ws.javaee.platform.v7.jndi_1.0.21.jar=874a3f4227a054a2fe315442b8e68c36
