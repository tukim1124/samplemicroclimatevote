#Tue Jun 19 06:25:10 BST 2018
lib/com.ibm.ws.security.mp.jwt.propagation_1.0.21.jar=5631c68bcd617d831aef7b2ea5cbd19d
lib/features/com.ibm.websphere.appserver.mpJwtPropagation-1.0.mf=0cf45e96c833ebb4c4daf70fa585a8fc
dev/api/stable/com.ibm.websphere.org.eclipse.microprofile.jwt.1.0_1.0.21.jar=062491ce63a0cb9aa0ec35b8c5f6c1ce
lib/com.ibm.ws.jaxrs.2.0.client_1.0.21.jar=df706071a2e1753cc434f1ba9096d468
