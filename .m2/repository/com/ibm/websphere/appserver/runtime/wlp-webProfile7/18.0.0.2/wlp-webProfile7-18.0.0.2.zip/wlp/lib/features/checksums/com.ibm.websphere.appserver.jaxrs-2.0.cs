#Tue Jun 19 06:25:10 BST 2018
lib/features/com.ibm.websphere.appserver.jaxrs-2.0.mf=c6077e180142006be6583b895db77760
