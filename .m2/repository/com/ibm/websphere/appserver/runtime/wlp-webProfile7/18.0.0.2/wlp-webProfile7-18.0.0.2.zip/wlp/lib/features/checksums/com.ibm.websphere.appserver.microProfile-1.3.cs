#Tue Jun 19 06:25:12 BST 2018
lib/features/com.ibm.websphere.appserver.microProfile-1.3.mf=3cf5bdcd2cca0fd14ae519da3d9b5c28
lib/com.ibm.ws.require.java8_1.0.21.jar=5de0ed4feb1dee14ece005df35bf77da
