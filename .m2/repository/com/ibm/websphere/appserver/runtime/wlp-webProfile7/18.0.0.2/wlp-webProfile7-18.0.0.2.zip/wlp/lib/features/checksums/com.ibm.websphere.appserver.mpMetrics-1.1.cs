#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.mpMetrics-1.1.mf=3feb415378e6dd6393722b131ade2b23
lib/com.ibm.ws.microprofile.metrics.1.1_1.0.21.jar=77aba064a0a9b827ee99254edbc5d9c3
lib/com.ibm.ws.require.java8_1.0.21.jar=5de0ed4feb1dee14ece005df35bf77da
