#Tue Jun 19 06:25:12 BST 2018
dev/api/third-party/com.ibm.websphere.appserver.thirdparty.eclipselink_1.0.21.jar=f2d2d0b97b12788a7af2f5b0771cd255
lib/features/com.ibm.websphere.appserver.org.eclipse.persistence-2.6.mf=0db10a583fae50ac149f862386d5083d
