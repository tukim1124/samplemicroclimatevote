#Tue Jun 19 06:25:11 BST 2018
lib/features/com.ibm.websphere.appserver.jaxrsejb-2.0.mf=2285599b7a1f4d8a6b6765ceca81b1db
lib/com.ibm.ws.jaxrs.2.0.ejb_1.0.21.jar=44f3daa706bd8b70c7c1e31d87d8b929
