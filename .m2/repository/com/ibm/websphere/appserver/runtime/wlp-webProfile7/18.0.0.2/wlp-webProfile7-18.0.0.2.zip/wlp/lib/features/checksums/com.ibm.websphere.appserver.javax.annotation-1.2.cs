#Tue Jun 19 06:25:11 BST 2018
dev/api/spec/com.ibm.websphere.javaee.annotation.1.2_1.0.21.jar=5b13edcf447e652d374790450639785a
lib/features/com.ibm.websphere.appserver.javax.annotation-1.2.mf=fb64ae2e15001fee7e72e1e9efaac523
