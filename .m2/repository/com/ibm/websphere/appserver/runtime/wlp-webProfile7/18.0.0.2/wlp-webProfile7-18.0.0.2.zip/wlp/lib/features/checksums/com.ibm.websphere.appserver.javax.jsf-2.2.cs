#Tue Jun 19 06:25:12 BST 2018
dev/api/spec/com.ibm.websphere.javaee.jsf.2.2_1.0.21.jar=6b7ddbefd884ae275ff9ad5369c70f05
lib/features/com.ibm.websphere.appserver.javax.jsf-2.2.mf=1e6fc34b8cc237e59ff314b4901b7fab
