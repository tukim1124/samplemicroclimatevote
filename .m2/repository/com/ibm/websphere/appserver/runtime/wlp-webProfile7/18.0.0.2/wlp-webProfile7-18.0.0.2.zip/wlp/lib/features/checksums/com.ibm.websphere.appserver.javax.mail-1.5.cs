#Tue Jun 19 06:25:10 BST 2018
lib/features/com.ibm.websphere.appserver.javax.mail-1.5.mf=6fb3bfaf349c07cf63598967c1bf48c3
lib/com.ibm.ws.com.sun.mail.javax.mail.1.5_1.5.21.jar=e5992aafe6115d257c9744e6f7a3f7db
